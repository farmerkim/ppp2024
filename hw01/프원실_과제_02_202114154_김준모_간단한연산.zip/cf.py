def c_to_f(c) :
    f = c * (9 / 5) + 32
    return f

print(c_to_f(30))

print(c_to_f(0))
