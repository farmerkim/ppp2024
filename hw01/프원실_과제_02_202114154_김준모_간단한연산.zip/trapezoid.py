a = 5
b = 3
h = 4

print(1/2*(a+b)*h)