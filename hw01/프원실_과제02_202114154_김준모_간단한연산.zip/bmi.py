weight = int((input("키를 입력하세요(단위: m) >>> ")))
height = int((input("몸무게를 입력하세요 >>> ")))

bmi = weight / (height * height)

print(bmi)