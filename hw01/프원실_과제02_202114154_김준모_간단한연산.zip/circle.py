r = 4

print({r*r*3.14})
